package com.example.journalcompose.ui.screen

import com.example.journalcompose.model.Favorite

data class FavState(
    val favorite: List<Favorite>,
//    val totalFavorite: Int
)