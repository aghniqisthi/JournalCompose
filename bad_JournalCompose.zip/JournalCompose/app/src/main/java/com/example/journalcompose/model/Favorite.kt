package com.example.journalcompose.model

data class Favorite(
    val id : Int,
    val status : Boolean,
    val journal: Journal
    )
