package com.example.journalcompose.ui.screen

import androidx.annotation.DrawableRes
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Devices
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.journalcompose.R
import com.example.journalcompose.model.Injection
import com.example.journalcompose.ui.theme.JournalComposeTheme
import com.example.journalcompose.viewmodel.DetailViewModel
import com.example.journalcompose.viewmodel.ViewModelFactory

@Composable
fun DetailScreen(
    id: Int,
    viewModel: DetailViewModel = viewModel(
        factory = ViewModelFactory(
            Injection.provideRepository()
        )
    ),
    navigateBack: () -> Unit,
    navigateToFav: () -> Unit
) {
    viewModel.uiState.collectAsState(initial = UiState.Loading).value.let { uiState ->
        when (uiState) {
            is UiState.Loading -> {
                viewModel.getJournalById(id)
            }
            is UiState.Success -> {
                val data = uiState.data
                DetailContent(
                    data.journal.id,
                    data.journal.title,
                    data.journal.volume,
                    data.journal.desc,
                    data.journal.link,
                    data.journal.image,
                    data.status,
                    onBackClick = navigateBack,
                    onClickToFav = {
                        if(data.status == false) viewModel.addFav(data.journal, data.status)
                        else viewModel.addFav(data.journal, data.status)
                        navigateToFav()
                    }
                )
            }
            is UiState.Error -> {}
        }
    }
}

@Composable
fun DetailContent(
    id: Int,
    title: String,
    volume: String,
    desc: String,
    link: String,
    @DrawableRes image: Int,
    statusFav: Boolean,
    onBackClick: () -> Unit,
    onClickToFav: (status: Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {

    var status by rememberSaveable { mutableStateOf(statusFav) }

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
//                .weight(1f)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(
            imageVector = Icons.Default.ArrowBack,
            contentDescription = "back",
            modifier = Modifier
                .padding(16.dp)
                .clickable { onBackClick() }
                .align(Alignment.Start)
        )
        Text(
            text = title,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.h5.copy(
                fontWeight = FontWeight.ExtraBold
            ),
            modifier = Modifier.fillMaxWidth()
        )
        Text(
            text = volume,
            textAlign = TextAlign.Center,
            style = MaterialTheme.typography.h5.copy(
                fontWeight = FontWeight.SemiBold
            ),
        )
        Image(
            painter = painterResource(image),
            contentDescription = null,
            modifier = modifier
                .padding(14.dp)
                .height(300.dp)
                .clip(RoundedCornerShape(20.dp))
        )
        Text(
            text = desc,
            style = MaterialTheme.typography.body2,
            textAlign = TextAlign.Justify,
        )
        Text(
            text = link,
            style = MaterialTheme.typography.subtitle1.copy(
                fontWeight = FontWeight.ExtraBold
            ),
            color = MaterialTheme.colors.primary
        )
        Spacer(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .background(Color.LightGray)
        )
        FavButton(
            status = status,
            enabled = true,
            onClick = {
                onClickToFav(status)
            }
        )
    }
}

@Composable
fun FavButton(
    status : Boolean,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onClick: () -> Unit,
) {
    Button(
        colors = if(status == false) ButtonDefaults.buttonColors(Color.Magenta) else ButtonDefaults.buttonColors(Color.Blue),
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp)
    ) {
        if(status == false){
            Icon(
                imageVector = Icons.Default.FavoriteBorder,
                contentDescription = "Click to Add Favorite",
                modifier = Modifier.size(50.dp).padding(16.dp)
            )
            Text(
                text = "Favorite",
                modifier = Modifier.align(Alignment.CenterVertically)
            )
        } else {
            Icon(
                imageVector = Icons.Default.Favorite,
                contentDescription = "Click to Delete Favorite",
                modifier = Modifier.padding(16.dp).size(24.dp)
            )
            Text(
                text = "Unfavorite",
                modifier = Modifier.align(Alignment.CenterVertically)
            )
        }

    }
}

@Preview(showBackground = true, device = Devices.PIXEL_4)
@Composable
fun DetailContentPreview() {
    JournalComposeTheme {
        DetailContent(
            1,
            "Information Systems",
            "Volume 10",
            "description journal lorem ipsum",
            "www.dicoding.com",
            R.drawable.information_systems,
            false,
            onBackClick = {},
            onClickToFav = {}
        )
    }
}